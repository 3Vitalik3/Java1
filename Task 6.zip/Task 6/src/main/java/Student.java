package main.java;
import java.util.HashMap;
import java.util.Map;

public class Student {
    private String fullName;
    private String phoneNumber;
    private int course;
    private Map<String, Integer> grades;  // Карта с оценками по предметам
    private int absenceCertificates; // Количество запрошенных справок
    private boolean expelled; // Флаг, указывающий, отчислен ли студент
    private static final int MIN_COURSE = 1;
    private static final int MAX_COURSE = 6;
    private static final int MIN_GRADE = 0;
    private static final int MAX_GRADE = 100;
    private static final int MAX_ABSENCE_CERTIFICATES = 3; // Максимальное количество справок

    // Конструктор класса Student проверяет корректность входных данных
    // и выбрасывает исключения в случае ошибок
    public Student(String fullName, String phoneNumber, int course) throws Exception {
        if (!fullName.matches("[А-Яа-яЁёA-Za-z]+( [А-Яа-яЁёA-Za-z]+){1,2}")) {
            throw new Exception("Неверный формат ФИО");
        }
        if (!phoneNumber.matches("\\+?\\d{10,15}")) {
            throw new Exception("Неверный формат телефона");
        }
        if (course < MIN_COURSE || course > MAX_COURSE) {
            throw new Exception("Курс должен быть от " + MIN_COURSE + " до " + MAX_COURSE);
        }

        this.fullName = fullName;
        this.phoneNumber = phoneNumber;
        this.course = course;
        this.grades = new HashMap<>();
        this.absenceCertificates = 0;
        this.expelled = false;

        Logger.logAction("Создан новый студент: " + this);
    }

    // Метод для добавления оценки по предмету
    // Проверяет корректность оценки
    public void addGrade(String subject, int grade) throws Exception {
        if (grade < MIN_GRADE || grade > MAX_GRADE) {
            throw new Exception("Оценка должна быть в диапазоне от " + MIN_GRADE + " до " + MAX_GRADE);
        }
        grades.put(subject, grade);
        Logger.logAction("Добавлен балл по предмету " + subject + " для студента " + fullName + ": " + grade);
    }

    // Метод для запроса справки для пропуска пары
    // Проверяет лимит справок и выбрасывает исключение
    public void requestAbsenceCertificate() throws Exception {
        if (absenceCertificates >= MAX_ABSENCE_CERTIFICATES) {
            throw new Exception("Превышен лимит справок для пропуска пары");
        }
        absenceCertificates++;
        Logger.logAction("Студент " + fullName + " запросил справку. Всего справок: " + absenceCertificates);
    }

    // Метод для отчисления студента
    // Проверяет, не был ли студент уже отчислен, и выбрасывает исключение в случае повторного отчисления
    public void expel() throws Exception {
        if (expelled) {
            throw new Exception("Студент отчислен");
        }
        expelled = true;
        Logger.logAction("Студент " + fullName + " был отчислен");
    }

    @Override
    public String toString() {
        return "ФИО: " + fullName + ", Телефон: " + phoneNumber + ", Курс: " + course;
    }
}