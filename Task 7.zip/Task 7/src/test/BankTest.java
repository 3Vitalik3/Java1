package test;

import bank.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class BankTest {

    @Test
    public void testDepositAndWithdraw() {
        Bank bank = new Bank();
        Person p = bank.createPerson("Тест");
        Account acc = bank.openAccount(p, AccountType.SAVINGS);

        bank.deposit(acc, 500);
        assertEquals(500, acc.getBalance(), 0.001);

        bank.withdraw(acc, 200);
        assertEquals(300, acc.getBalance(), 0.001);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithdrawMoreThanBalance() {
        Bank bank = new Bank();
        Person p = bank.createPerson("Тест");
        Account acc = bank.openAccount(p, AccountType.SAVINGS);

        bank.deposit(acc, 100);
        bank.withdraw(acc, 200); // Должно выбросить исключение
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNegativeDeposit() {
        Bank bank = new Bank();
        Person p = bank.createPerson("Тест");
        Account acc = bank.openAccount(p, AccountType.SAVINGS);

        bank.deposit(acc, -50); // Должно выбросить исключение
    }

    @Test
    public void testInterest() {
        Bank bank = new Bank();
        Person p = bank.createPerson("Тест");
        Account acc = bank.openAccount(p, AccountType.SAVINGS);

        bank.deposit(acc, 1000);
        bank.applyInterest(acc);
        assertEquals(1030, acc.getBalance(), 0.001);
    }

    @Test
    public void testLogger() {
        Logger logger = Logger.getInstance();
        logger.clear();

        logger.log("Операция 1");
        logger.log("Операция 2");

        assertEquals(2, logger.getLog().size());
        assertEquals("Операция 1", logger.getLog().get(0));
    }
}