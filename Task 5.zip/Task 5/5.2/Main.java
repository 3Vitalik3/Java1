import factories.ArcherFactory;
import factories.MageFactory;
import factories.WariorFactory;
import warriors.Warior;

public class Main {
    public static void main(String[] args) {
        // создание магов
        WariorFactory mageFactory = new MageFactory(9, 6, 75, 2, "Fire магия");
        // создание лучников
        WariorFactory archerFactory = new ArcherFactory(3, 8, 90, 4, 19);

        // Создаём мага farm
        Warior mage = mageFactory.createWarior();
        // информация о маге
        mage.showInfo();
        mage.useUniqueAbility();

        // Создаём лучника
        Warior archer = archerFactory.createWarior();
        // информация о лучнике
        archer.showInfo();
        archer.useUniqueAbility();
    }
}