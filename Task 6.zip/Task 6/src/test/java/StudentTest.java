package test.java;
import main.java.Student;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class StudentTest {

    @Test
    void testStudentCreationSuccess() throws Exception {
        Student student = new Student("Иван Иванов", "+79991234567", 3);
        assertEquals("ФИО: Иван Иванов, Телефон: +79991234567, Курс: 3", student.toString());
    }

    @Test
    void testStudentCreationInvalidPhoneNumber() {
        Exception exception = assertThrows(Exception.class, () -> {
            new Student("Иван Иванов", "123456", 3);
        });
        assertEquals("Неверный формат телефона", exception.getMessage());
    }

    @Test
    void testStudentCreationInvalidCourse() {
        Exception exception = assertThrows(Exception.class, () -> {
            new Student("Иван Иванов", "+79991234567", 7);
        });
        assertEquals("Курс должен быть от 1 до 6", exception.getMessage());
    }

    @Test
    void testAddGradeSuccess() throws Exception {
        Student student = new Student("Иван Иванов", "+79991234567", 3);
        student.addGrade("Математика", 85);
    }

    @Test
    void testAddGradeInvalidGrade() throws Exception {
        Student student = new Student("Иван Иванов", "+79991234567", 3);
        Exception exception = assertThrows(Exception.class, () -> {
            student.addGrade("Математика", 150);
        });
        assertEquals("Оценка должна быть в диапазоне от 0 до 100", exception.getMessage());
    }

    @Test
    void testRequestAbsenceCertificateSuccess() throws Exception {
        Student student = new Student("Иван Иванов", "+79991234567", 3);
        student.requestAbsenceCertificate();
        student.requestAbsenceCertificate();
        student.requestAbsenceCertificate();
    }

    @Test
    void testRequestAbsenceCertificateLimitExceeded() throws Exception {
        Student student = new Student("Иван Иванов", "+79991234567", 3);
        student.requestAbsenceCertificate();
        student.requestAbsenceCertificate();
        student.requestAbsenceCertificate();
        Exception exception = assertThrows(Exception.class, student::requestAbsenceCertificate);
        assertEquals("Превышен лимит справок для пропуска пары", exception.getMessage());
    }

    @Test
    void testExpelStudentSuccess() throws Exception {
        Student student = new Student("Иван Иванов", "+79991234567", 3);
        student.expel();
    }

    @Test
    void testExpelStudentAlreadyExpelled() throws Exception {
        Student student = new Student("Иван Иванов", "+79991234567", 3);
        student.expel();
        Exception exception = assertThrows(Exception.class, student::expel);
        assertEquals("Студент уже отчислен", exception.getMessage());
    }
}
