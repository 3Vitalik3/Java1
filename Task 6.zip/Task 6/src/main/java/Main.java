package main.java;
public class Main {
    public static void main(String[] args) {
        try {
            // Создаем первого студента
            Student student1 = new Student("Петр Петров", "+79891337111", 2);

            // оценкf по предмету
            student1.addGrade("Русский язык", 95);

            // Запрашиваем справку для пропуска пары три раза
            student1.requestAbsenceCertificate();
            student1.requestAbsenceCertificate();
            student1.requestAbsenceCertificate();

            // Попытка запросить еще одну справку (должна вызвать ошибку)
            student1.requestAbsenceCertificate();

            // Отчисляем студента
            student1.expel();

            // Попытка добавить неправильную оценку (должна вызвать ошибку)
            student1.addGrade("Физика", 150);
        } catch (Exception e) {
            // Логируем ошибку
            Logger.logError("Ошибка: " + e.getMessage());
        }

        try {
            // Попытка создать студента с неверным телефоном (должна вызвать ошибку)
            Student student2 = new Student("Петр Петров", "123456", 2);
        } catch (Exception e) {
            // Логируем ошибку при создании студента
            Logger.logError("Ошибка при создании студента: " + e.getMessage());
        }
    }
}