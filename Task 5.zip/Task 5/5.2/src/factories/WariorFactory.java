package factories;

import warriors.Warior;

public interface WariorFactory {
    Warior createWarior();
}