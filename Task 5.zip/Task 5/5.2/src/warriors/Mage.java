package warriors;

public class Mage extends Warior {
    private String magicType;

    public Mage(int attack, int defense, int health, int level, String magicType) {
        super(attack, defense, health, level);
        this.magicType = magicType;
        System.out.println("Создан Mage: он практикует " + magicType);
    }

    @Override
    public void useUniqueAbility() {
        System.out.println("Mage кастует мощное заклинание " + magicType + "!");
    }
}