package main.java;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Logger {
    private static String logFile = "actions.log";
    private static String errorLogFile = "errors.log";

    public static void setLogFile(String file) {
        logFile = file;
    }

    public static void setErrorLogFile(String file) {
        errorLogFile = file;
    }

    // Метод для логирования действий
    // Записывает сообщение в лог-файл с временной меткой
    public static void logAction(String message) {
        log(message, logFile);
    }

    // Метод для логирования ошибок
    // Записывает сообщение об ошибке в лог-файл с временной меткой
    public static void logError(String message) {
        log(message, errorLogFile);
    }

    // Вспомогательный метод для записи сообщений в файлы
    private static void log(String message, String fileName) {
        try (OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(fileName, true), StandardCharsets.UTF_8)) {
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            writer.write(timestamp + " - " + message + "\n");
        } catch (IOException e) {
            System.err.println("Ошибка записи в лог-файл: " + e.getMessage());
        }
    }
}