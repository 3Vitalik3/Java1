package warriors;

public class Archer extends Warior {
    private int range;

    public Archer(int attack, int defense, int health, int level, int range) {
        super(attack, defense, health, level);
        this.range = range;
        System.out.println("Создан Archer: дальность стрельбы " + range);
    }

    @Override
    public void useUniqueAbility() {
        System.out.println("Archer выпускает залп стрел с расстояния " + range + " метров!");
    }
}