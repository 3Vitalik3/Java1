import bank.*;

public class Main {
    public static void main(String[] args) {
        Bank bank = new Bank();

        // Создаем клиента с именем "Петр Петров"
        Person p1 = bank.createPerson("Петр Петров");

        // Открываем два счета для клиента: сберегательный и расчетный
        Account acc1 = bank.openAccount(p1, AccountType.SAVINGS);   // Счет с процентами
        Account acc2 = bank.openAccount(p1, AccountType.CHECKING);  // Счет без процентов

        // Вносим на первый счет 11000 рублей
        bank.deposit(acc1, 11000);

        // Снимаем с первого счета 2600 рублей
        bank.withdraw(acc1, 2600);

        // Вносим на второй счет 300 рублей
        bank.deposit(acc2, 300);

        // Выводим балансы обоих счетов
        System.out.println("Баланс счета 1: " + acc1.getBalance());
        System.out.println("Баланс счета 2: " + acc2.getBalance());

        // Начисляем проценты на первый счет (если они предусмотрены)
        bank.applyInterest(acc1);

        // Выводим баланс первого счета после начисления процентов
        System.out.println("Баланс счета 1 после начисления процентов: " + acc1.getBalance());

        // журнал всех операций
        Logger.getInstance().printLog();
    }
}
